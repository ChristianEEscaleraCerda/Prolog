sumaCuadrada :: Int -> Int
sumaCuadrada n = sum [x^2 | x <- [1..n]]

sumadown :: Int -> Int
sumadown 0 = 0
sumadown n = n + sumaDecremento (n-1)




