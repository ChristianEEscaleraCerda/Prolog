main = do
    putStrLn "hello, everybody"
    putStrLn ("Please look at my favorite odd numbrers: " ++ show (filter odd [10, 20, 30]))