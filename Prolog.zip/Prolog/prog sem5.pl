room(kitchen).
room(office).
room(hall).
room('dining room').
room(cellar).

door(office, hall).
door(kitchen, office).
door(hall, 'dining room').
door(kitchen, cellar).
door('dining room', kitchen).

location(desk, office).
location(apple, kitchen).
location(flashlight, desk).
location('washing machine', cellar).
location(broccoli, kitchen).
location(crackers, kitchen).
location(computer, office).
location(envelope, desk).
location(stamp, envelope).
location(key, envelope).

edible(apple).
edible(crackers).

tastes_yucky(broccoli).

:-dynamic here/1.
here(kitchen).

where_food(apple,kitchen).
where_food(crackers,kitchen).
where_food(brocoli,kitchen).

connect(X,Y) :- door(X,Y).
connect(X,Y) :- door(Y,X).


list_things(Place) :-
location(X, Place),
tab(2),
write(X),
nl,
fail.
list_things(_).

list_connections(Place) :-
connect(Place, X),
tab(2),
write(X),
nl,
fail.
list_connections(_).

look :-
here(Place),
write('You are in the '), write(Place), nl,
write('You can see:'), nl,
list_things(Place),
write('You can go to:'), nl,
list_connections(Place).

goto(Place):-
 can_go(Place),
 move(Place),
 look.

can_go(Place):-
 here(X),
 connect(X, Place).
can_go(_):-
 write('You can''t get there from here.'), nl,
 fail.

move(Place):-
 retract(here(_)),
 asserta(here(Place)).

take(X):-
 can_take(X),
 take_object(X).

can_take(Thing) :-
 here(Place),
 location(Thing, Place).
can_take(Thing) :-
 write('There is no '), write(Thing),
 write(' here.'),
 nl, fail.

take_object(X):-
 retract(location(X,_)),
 asserta(have(X)),
 write('taken'), nl.

backtracking_assert(X):-
 asserta(X).
backtracking_assert(X):-
 retract(X),fail.

is_contained_in(T1,T2) :-
location(T1,T2).

is_contained_in(T1,T2) :-
location(X,T2),
is_contained_in(T1,X).

is_contained_in(T1,T2):-
location(T1,X),
is_contained_in(X,T2).

object(candle, red, small, 1).
object(apple, red, small, 1).
object(apple, green, small, 1).
object(table, blue, big, 50).

location_s(object(candle, red, small, 1), kitchen).
location_s(object(apple, red, small, 1), kitchen).
location_s(object(apple, green, small, 1), kitchen).
location_s(object(table, blue, big, 50), kitchen).

can_take_s(Thing) :-
here(Room),
location_s(object(Thing, _, small,_), Room).
can_take_s(Thing) :-
here(Room),
location_s(object(Thing, _, big, _), Room),
write('The '), write(Thing),
write(' is too big to carry.'), nl,
fail.
can_take_s(Thing) :-
here(Room),
not(location_s(object(Thing, _, _, _), Room)),
write('There is no '), write(Thing), write(' here.'), nl,
fail.

factorial(0,1).

factorial(N,F) :-
N>0,
N1 is N-1,
factorial(N1,F1),
F is N * F1.
