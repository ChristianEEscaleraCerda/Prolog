male(adolfo).
male(christian).

female(valeria).
female(silvia).


parent(adolfo,valeria).
parent(adolfo,christian).
parent(silvia,valeria).
parent(silvia,christian).
